require 'busted.modules.output_handler_loader'()

