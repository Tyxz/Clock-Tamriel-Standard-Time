require 'busted.modules.test_file_loader'(busted, {'lua'})

