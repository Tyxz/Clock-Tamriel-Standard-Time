-- supporting testfile; belongs to 'cl_spec.lua'

describe('Tests list', function()
  it('test 1', function()
  end)

  it('test 2', function()
  end)

  it('test 3', function()
  end)
end)
